import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

/* (Full component code omitted for brevity; inserted dynamically below if needed.) */
